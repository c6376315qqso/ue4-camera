// Fill out your copyright notice in the Description page of Project Settings.

#include "CityPark2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CityPark2, "CityPark2" );
